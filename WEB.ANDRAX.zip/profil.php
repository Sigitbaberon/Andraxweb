<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include('koneksi.php');

// Cek apakah sesi username telah diinisialisasi dengan benar
if (!isset($_SESSION['username'])) {
    echo "Sesi username tidak diinisialisasi. Harap pastikan Anda sudah login.";
    exit();
}

// Ambil username dari sesi
$username = $_SESSION['username'];

// Gunakan prepared statements untuk mencegah SQL injection
$query = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Periksa apakah kueri berhasil dieksekusi
if (!$result) {
    echo "Kesalahan dalam eksekusi kueri: " . $conn->error;
    exit();
}

// Periksa apakah ada data pengguna yang ditemukan
if ($result->num_rows > 0) {
    // Ambil data pengguna
    $row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <!-- Add Bootstrap stylesheet -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- Add Font Awesome stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #343a40;
            color: #ffffff;
            padding-top: 20px;
        }

        .container {
            margin-top: 20px;
        }

        .card {
            background-color: #495057;
            border: 1px solid #343a40;
            margin-bottom: 20px;
            color: #ffffff;
        }

        .card-title {
            color: #00ff33;
            font-size: 1.2rem;
        }

        .btn-logout {
            background-color: #ffc107;
            color: #343a40;
            border: 1px solid #ffc107;
        }

        .btn-logout:hover {
            background-color: #ffca2c;
            color: #343a40;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card-deck">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-user"></i> Username</h5>
                            <p class="card-text"><?php echo $row['username']; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-envelope"></i> Email</h5>
                            <p class="card-text"><?php echo $row['email']; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-key"></i> Password</h5>
                            <p class="card-text"><?php echo $row['password']; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-phone"></i> Phone</h5>
                            <p class="card-text"><?php echo $row['phone']; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><i class="fas fa-wallet"></i> Balance</h5>
                            <p class="card-text"><?php echo $row['balance']; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Add more Bootstrap components or customize as needed -->

                <a class="btn btn-logout mt-4" href="logout.php">Logout</a>
            </div>
        </div>
    </div>

    <!-- Add Bootstrap JavaScript and jQuery if needed -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>


<?php
} else {
    echo "Data pengguna tidak ditemukan.";
}

// Tutup koneksi
$stmt->close();
$conn->close();
?>
