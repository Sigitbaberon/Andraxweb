<?php
include('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Gunakan prepared statements untuk mencegah SQL injection
    $sql = "SELECT * FROM users WHERE username=? AND password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Periksa apakah hasil kueri mengembalikan satu baris (user valid)
    if ($result->num_rows == 1) {
        // Login berhasil, atur sesi dan arahkan ke halaman home.html
        session_start();
        $_SESSION['username'] = $username;
        header("Location: home.html");
        exit();
    } else {
        // Login gagal, arahkan ke halaman login.html dengan pesan error
        header("Location: login.html?error=1");
        exit();
    }
}

// Tutup koneksi
$conn->close();
?>
