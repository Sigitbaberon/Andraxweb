<?php
include('koneksi.php');

// Ambil data dari formulir
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

// Simpan data ke tabel pengguna
$sql = "INSERT INTO users (username, email, phone, password) VALUES ('$username', '$email', '$phone', '$password')";

if ($conn->query($sql) === TRUE) {
    // Redirect ke halaman home.html jika penyimpanan berhasil
    header("Location: home.html");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi
$conn->close();
?>
