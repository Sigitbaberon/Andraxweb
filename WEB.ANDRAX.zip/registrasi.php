<?php
include('koneksi.php');

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    if (empty($nama) || empty($username) || empty($password) || empty($email)) {
        $error = 'Semua field harus diisi.';
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO tabel_user (nama, username, password, email) VALUES ('$nama', '$username', '$hashed_password', '$email')";

        if ($koneksi->query($query) === TRUE) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['nama'] = $nama;

            header("Location: home.php");
            exit();
        } else {
            $error = 'Terjadi kesalahan. Silakan coba lagi.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Andrax</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
    
    
    
        /* your CSS styles here */
        
           body {
      background-color: #000;
      color: #fff;
      font-family: Arial, sans-serif;
    }

    header {
      background-color: #000;
      padding: 20px;
      text-align: center;
    }

    h1 {
      color: #00ff33;
      font-size: 36px;
      margin-bottom: 10px;
      text-transform: uppercase;
    }

    .container {
      background-color: #000;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }

    form {
      margin-bottom: 20px;
    }

    form label {
      display: block;
      margin-bottom: 10px;
      font-weight: bold;
    }

    form input {
      width: 100%;
      padding: 10px;
      border: none;
      background-color: #333;
      color: #fff;
      border-radius: 5px;
    }

    form button {
      padding: 10px 20px;
      background-color: #00ff33;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .login-link {
      text-align: center;
      margin-top: 10px;
    }

    .login-link a {
      color: #00ff33;
    }

    footer {
      background-color: #000;
      padding: 30px 0;
      text-align: center;
    }

    footer h3 {
      color: #00ff33;
      font-size: 24px;
      margin-bottom: 20px;
      text-transform: uppercase;
    }

    footer ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    footer ul li {
      margin-bottom: 10px;
    }

    footer ul li i {
      margin-right: 10px;
      color: #00ff33;
      font-size: 20px;
    }

    footer p {
      margin-bottom: 0;
      color: #ccc;
    }

    footer .social-icons {
      list-style: none;
      padding: 0;
      margin-top: 20px;
    }

    footer .social-icons li {
      display: inline-block;
      margin-right: 10px;
    }

    footer .social-icons a {
      display: flex;
      align-items: center;
      justify-content: center;
      color: #00ff33;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: #000;
      transition: background-color 0.3s ease;
    }

    footer .social-icons a:hover {
      background-color: #00ff33;
    }
        
        
        
    </style>
    
    
    
    
    
    
</head>

<body>
    <header>
        <div class="container">
            <h1>Register Andrax</h1>
        </div>
    </header>

    <main>
        <div class="container">
            <form method="post" action="">
                <div class="mb-3">
                    <label for="username" class="form-label"><i class="fas fa-user"></i> Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="fas fa-envelope"></i> Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label"><i class="fas fa-phone"></i> Phone</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label"><i class="fas fa-lock"></i> Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit"><i class="fas fa-user-plus"></i> Register</button>
            </form>
            <div class="login-link">
                <p>Sudah punya akun? <a href="login.php">Login disini</a></p>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <h3>Temukan Kami di Sosial Media</h3>
            <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
