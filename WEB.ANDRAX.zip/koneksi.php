<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "sql306.infinityfree.com";
$username = "if0_35444445";
$password = "Andrax21";
$database = "if0_35444445_ANDRAX";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
